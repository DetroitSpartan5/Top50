export default function Page() {
  return (
    <main style={ padding: 24 }>
      <h1>My Top 50</h1>
      <p>Placeholder — wire up Supabase here.</p>
    </main>
  )
}