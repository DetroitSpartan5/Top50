export default function Page() {
  return (
    <main style={ padding: 24 }>
      <h1>Sign Up</h1>
      <p>Placeholder — wire up Supabase here.</p>
    </main>
  )
}